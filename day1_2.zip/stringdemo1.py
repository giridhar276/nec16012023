val = 10
print(val)
print("value is",val)
print(10,20,30,40,50)

name = "python programming"
print(name)
print("I love",name)

# string[start:stop:step]   # default step is 1
name = "python programming"
print(name)
print(name[0])
print(name[1])
print(name[0:5])
print(name[3:9])
print(name[0:17:2])
print(name[1:17:2])
print(name[3:17:3])
print(name[::])   #python programming
print(name[:])   #python programming
print(name[-1])
print(name[-2])
print(name[-4:-2])
print(name[-2:-4:-1])

name = "python programming"
print(len(name))  # total no.of characters
print(name.capitalize())
print(name.upper())
print(name.lower())
print(name.center(25))
print(name.center(25,"*"))
print(name.count('p'))
print(name.count('P'.lower()))
print(name.startswith("p"))
print(name.startswith("q"))
print(name.endswith("g"))
print(name.endswith("m"))
print(name.isupper())
print(name.islower())
print(name.split(" "))
print(name.find("mm")) # if existing.. return the index of m
print(name.find("q"))  # if not existing.. will return -1
print(name.replace('python','java'))
print(name)  # actual string will remain same
aname = " python   "
print(len(aname))
print(len(aname.strip()))  # will remove whitespaces at both ends
print(len(aname.rstrip()))
name = "python programming"
print(name.title())







name = "pythonprogramming"
print(name.isalpha())





name = name.replace('python','java')
print(name)



# for loop with string
name = "python"
print(name)#python
for char in name :
    print(char)

# for loop with range(start,stop,step)

for val in range(10):
    print(val)

for val in range(1,10):
    print(val)
    
for val in range(1,10):
    print(val)

for val in range(1,10,2):
    print(val)

# for loop with list
alist = [10,20,30,40]
for val in alist:
    print(val)
    
for val in range(-10,-1):
    print(val)
    
for val in range(10,1,-1):
    print(val)






