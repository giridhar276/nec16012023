
import os
#os.remove('sample.txt')

print(os.listdir())


# display all the files and directories from current directory
for file in os.listdir():
    print(file)
    
    
    
for file in os.listdir("C:\\"):
    print(file)    
    
    
import datetime
print(datetime.datetime.now())


print(os.path.getsize('notes.txt'))

print(os.stat('notes.txt').st_size)