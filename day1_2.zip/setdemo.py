


aset = {10,20,20,20,30,30}
bset = {30,30,30,30,40,50,50}

print(aset)
print(bset)

aset.add(10)
print(aset)


print(aset.union(bset))
print(aset.intersection(bset))
print(aset.difference(bset))
print(aset.issubset(bset))

