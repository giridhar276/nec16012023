



name = input("Enter any name :")
print(name)


val = 10
print(type(val))

alist = [10,210,22]
print(type(alist))


print(max(alist))

print(min(alist))

print(sum(alist))