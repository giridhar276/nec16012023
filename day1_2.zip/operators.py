name = "python programming"
if "pro" in name:
    print("substring exists")

alist = [10,20,30,40]
if 10 in alist:
    print("exists")
    
book = {"chap1":10,"chap2":20}
if "chap1" in book:
    print("key exists")
    
#objects should be of same type
print("python" + str(9))
print([10,20] + list((30,40)))


print("python" * 5)

print([10,20] * 4)

