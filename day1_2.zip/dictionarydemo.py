# dictionary is all about keys and values
book = {"chap1":10 ,"chap2":20,"chap3":30}
print(book)
# accessing individual values
print(book["chap1"])
print(book["chap2"])
# add new key:value
book["chap4"] = 40
book["chap5"] = 50
print(book)

# display keys
print(book.keys())

for key in book.keys():
    print(key)
       
# display values
print(book.values())

for value in book.values():
    print(value)
    
# display key:value
print(book.items())

for k,v in book.items():
    print(k,v)

for item in book.items():
    print(item)
    



