alist = [10,45,34,23,65,24,75,21]
print(alist)
## list.append(value)  - add single value
alist.append(92)

print('After appending :',alist)
# list.extend(list)  -  add multiple values
alist.extend([23,95,59])
print("After extending :",alist)
# list.insert(index,value)
alist.insert(2,300)
print('After indexing :',alist)

#alist.pop(index)
alist.pop()  # if index is not passed.. will remove last value
print('After pop :',alist)
alist.pop(2)
print('After pop :',alist)
#alist.remove(value)
alist.remove(45)
print('After removing :',alist)
#alist.remove(4500)
#print('After removing :',alist)
print(alist)
# to find the index of any particular value
print(alist.index(24))
# sorting
alist.sort()  # default: ascending order
print('After sorting :', alist)
alist.sort(reverse = True)
print('After sorting :', alist)

alist = [10,45,34,23,65,24,75,21]
alist.reverse()
print('After reversing :',alist)



alist = [10,10,10,10,45,34,23,65,24,75,21]
print(set(alist))
