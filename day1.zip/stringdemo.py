print('python programming')
print('python programming')
print('java programming')
print('python programming')

# this line is commented
# this is single line comment
#print('python programming')

'''
print('python programming')
print('python programming')
print('java programming')
print('python programming')
'''

"""
print('python programming')
print('python programming')
"""