# list
alist = [10,20,30,40]
print(alist[0])
alist[0] = 100
print('After replacing',alist)


# tuple
atup = (10,20,30,40)
atup[0] = 1000
print("After replacing",atup)

# type casting - converting from one object to another object
atup = (10,20,30,40)
# convert tuple to list
alist = list(atup)
# making changes
alist[0] = 1000
# converting list to tuple
atup = tuple(alist)
print(atup)


#string - immutable
name = "python"
name[0] = "z"
print(name)
